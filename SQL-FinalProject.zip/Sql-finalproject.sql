#Part1 
#Question 1 create a table named Authors
create table Authors (
  AuthorID int auto_increment primary key,
  FullName varchar(255) NOT NULL,
  BirthCountry varchar(255) not null);
  #Question 2 Add the following Author names & Country
  insert into Authors (FullName, BirthCountry)
values 
('Jane Austen', 'England'),
('Charles Dickens', 'England'),
('Mark Twain', 'United States');
# Question 3 to see Authors
select * from Authors;
#Part 2
#Question 4 creates a table named Books
create table Books (
 BookID int auto_increment primary key,
 name varchar(255),
 AuthorID int,
 foreign key (AuthorID) references Authors(AuthorID));
 #Question 5 insert the books into the table
 insert into Books (name, AuthorID)
values
("Pride and Prejudice", 1),
("Sense and Sensibility", 1),
("The Pickwick Papers", 2);
#Question 6 run a query 
select * from Books;
#Part3
#Question7 joins the Authors and Books table together
select a.FullName as AuthorName, b.name as BookName
from Authors a
join Books b
on a.AuthorID = b.AuthorID
order by a.FullName;
#Question 8 create the view authorbooks
create view AuthorBooks as
select a.FullName as AuthorName, b.name as BookName
from Authors a
join Books b
on a.AuthorID = b.AuthorID
order by a.FullName;
#Question9 Run query
select * from AuthorBooks;